//////Bibliotecas//////
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
using namespace sf;
//////Variables//////
Texture texture_color1;
Texture texture_color2;
Texture texture_color3;
Texture texture_color4;
Sprite sprite_1;
Sprite sprite_2;
Sprite sprite_3;
Sprite sprite_4;

///Punto de entrada a la aplicaci�n///
int main() {
	//Cargamos la textura del archivo
	texture_color1.loadFromFile("cuad_red.png");
	texture_color2.loadFromFile("cuad_yellow.png");
	texture_color3.loadFromFile("cuad_blue.png");
	texture_color4.loadFromFile("cuad_grey.png");
	//Cargamos el material del sprite
	sprite_1.setTexture(texture_color1);
	sprite_2.setTexture(texture_color2);
	sprite_3.setTexture(texture_color3);
	sprite_4.setTexture(texture_color4);
	//Movemos el sprite
	sprite_1.setPosition(1, 0);
	sprite_2.setPosition(402, 0);
	sprite_3.setPosition(0, 400);
	sprite_4.setPosition(402, 400);

	sprite_1.setScale(1.57, 1.57);
	sprite_2.setScale(0.78, 0.78);
	sprite_3.setScale(3.4, 3.4);
	sprite_4.setScale(6.3, 6.3);
    
	
	sf::RenderWindow App(sf::VideoMode(800, 800),"Escalado 4 colores");
	// Loop principal
	while (App.isOpen()) {
		// Limpiamos la ventana
		App.clear();
		// Dibujamos la escena
		App.draw(sprite_1);
		App.draw(sprite_2);
		App.draw(sprite_3);
		App.draw(sprite_4);
		// Mostramos la ventana
		App.display();
	}
	return 0;
}
