#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>

using namespace sf;

Texture texture;
Sprite sprite;


int main() {

	texture.loadFromFile("blanco.png");
	sprite.setTexture(texture);

	sprite.setPosition(400, 300);
	sprite.setScale(2.5, 0.2);

	sf::RenderWindow App(sf::VideoMode(800, 600),"Rotar Sprite");


	while (App.isOpen())
	{
		sprite.setRotation(sprite.getRotation() + 0.8);

		App.clear();

		App.draw(sprite);

		App.display();
	}
	return 0;
}