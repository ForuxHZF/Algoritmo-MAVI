
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
using namespace sf;

Texture texture_cuadro1;
Texture texture_cuadro2;


Sprite sprite1;
Sprite sprite2;

int main() {
    texture_cuadro1.loadFromFile("blanco.png");
    texture_cuadro2.loadFromFile("negro.png");

    sprite1.setTexture(texture_cuadro1);
    sprite2.setTexture(texture_cuadro2);


    sf::RenderWindow App(sf::VideoMode(800, 800), "Tablero de ajedrez");

    bool blanco = true;

    while (App.isOpen()) {
        App.clear();

        for (int y = 0; y < 8; y++) {
            for (int x = 0; x < 8; x++) {
                if (blanco) {
                    sprite1.setPosition(x * 100, y * 100);
                    App.draw(sprite1);
                }
                else {
                    sprite2.setPosition(x * 100, y * 100);
                    App.draw(sprite2);
                }

                blanco = !blanco;
            }

            blanco = !blanco;
        }

        App.display();
    }

    return 0;
}