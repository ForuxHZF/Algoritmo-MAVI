#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>

using namespace sf;
Texture textureFondo;
Texture texture1;
Texture texture2;
Texture texture3;
Texture texture4;
Texture texture5;
Texture texture6;
Texture texture7;
Texture texture8;

Sprite spriteFondo;
Sprite sprite1;
Sprite sprite2;
Sprite sprite3;
Sprite sprite4;
Sprite sprite5;
Sprite sprite6;
Sprite sprite7;
Sprite sprite8;



int main() {
	textureFondo.loadFromFile("fondo.jpg");
	texture1.loadFromFile("plataforma.jpg");
	texture2.loadFromFile("plataforma.jpg");
	texture3.loadFromFile("plataforma.jpg");
	texture4.loadFromFile("plataforma.jpg");
	texture5.loadFromFile("plataforma.jpg");
	texture6.loadFromFile("plataforma.jpg");
	texture7.loadFromFile("plataforma.jpg");
	texture8.loadFromFile("plataforma.jpg");

	spriteFondo.setTexture(textureFondo);
	sprite1.setTexture(texture1);
	sprite2.setTexture(texture2);
	sprite3.setTexture(texture3);
	sprite4.setTexture(texture4);
	sprite5.setTexture(texture5);
	sprite6.setTexture(texture6);
	sprite7.setTexture(texture7);
	sprite8.setTexture(texture8);

	spriteFondo.setPosition(0, 0);
	sprite1.setPosition(0, 550);
	sprite2.setPosition(80, 500);
	sprite3.setPosition(160, 450);
	sprite4.setPosition(240, 400);
	sprite5.setPosition(320, 350);
	sprite6.setPosition(400, 300);
	sprite7.setPosition(480, 250);
	sprite8.setPosition(560, 250);

	sprite1.setScale(0.2, 2);
	sprite2.setScale(0.2, 2);
	sprite3.setScale(0.2, 2);
	sprite4.setScale(0.2, 2);
	sprite5.setScale(0.2, 2);
	sprite6.setScale(0.2, 2);
	sprite7.setScale(0.2, 2);
	sprite8.setScale(0.8, 0.08);

	textureFondo.setSmooth(true);
	texture1.setSmooth(true);
	texture2.setSmooth(true);
	texture3.setSmooth(true);
	texture4.setSmooth(true);
	texture5.setSmooth(true);
	texture6.setSmooth(true);
	texture7.setSmooth(true);
	texture8.setSmooth(true);

	sf::RenderWindow App(sf::VideoMode(800, 600),"Plataformas");




	while (App.isOpen())
	{
		App.clear();

		App.draw(spriteFondo);
		App.draw(sprite1);
		App.draw(sprite2);
		App.draw(sprite3);
		App.draw(sprite4);
		App.draw(sprite5);
		App.draw(sprite6);
		App.draw(sprite7);
		App.draw(sprite8);

		App.display();
	}
	return 0;
}