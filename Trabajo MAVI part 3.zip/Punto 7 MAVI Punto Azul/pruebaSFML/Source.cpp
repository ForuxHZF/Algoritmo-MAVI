//////Bibliotecas//////
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
using namespace sf;
//////Variables//////
Texture texture_1;
Texture texture_2;
Texture texture_3;
Texture texture_4;
Texture texture_5;

Sprite sprite_1;
Sprite sprite_2;
Sprite sprite_3;
Sprite sprite_4;
Sprite sprite_5;


int main() {
	
	texture_1.loadFromFile("rcircle.png");
	texture_2.loadFromFile("rcircle.png");
	texture_3.loadFromFile("rcircle.png");
	texture_4.loadFromFile("rcircle.png");
	texture_5.loadFromFile("circle_blue.png");

	sprite_1.setTexture(texture_1);
	sprite_2.setTexture(texture_2);
	sprite_3.setTexture(texture_3);
	sprite_4.setTexture(texture_4);
	sprite_5.setTexture(texture_5);

	sprite_1.setPosition(674, 0);
	sprite_2.setPosition(674, 472);
	sprite_3.setPosition(0, 472);
	sprite_4.setPosition(-1, -1);
	sprite_5.setPosition(340, 240);

	sf::RenderWindow App(sf::VideoMode(800, 600),"Punto Azul");
	
	while (App.isOpen()) {
		
		App.clear();
		

		App.draw(sprite_1);
		App.draw(sprite_2);
		App.draw(sprite_3);
		App.draw(sprite_4);
		App.draw(sprite_5);

		App.display();
	}
	return 0;
}
