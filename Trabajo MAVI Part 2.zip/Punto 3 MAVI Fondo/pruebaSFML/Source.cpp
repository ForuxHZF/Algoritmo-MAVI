#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
using namespace sf;

Texture texture;
Sprite sprite;

int main() {

	texture.loadFromFile("fondo.jpg");

	sprite.setTexture(texture);

	sf::RenderWindow App(sf::VideoMode(800, 600), "Fondo Videojuego");
	
	texture.setSmooth(true);

	while (App.isOpen())
	{

		App.clear();

		App.draw(sprite);

		App.display();
	}
	return 0;
}